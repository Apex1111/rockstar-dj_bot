<p align="center">
    <a href="https://app.codacy.com/manual/mr-dark-prince/alexasongbot/dashboard"> <img src="https://img.shields.io/codacy/grade/4d58f2a402b54aed8a7d95f7add45a81?color=brightgreen&logo=codacy&logoColor=green&style=for-the-badge" alt="Codacy" /></a>
</p>

# Alexa Song Bot
![logo](https://telegra.ph/file/dbed7ae52ae9e91261abc.jpg)
Reach me on Telegram 

## How To Host
The easiest way to deploy this Song Bot
<p align="center"><a href="https://heroku.com/deploy?template=https://github.com/MR-SHRLCK/Alexa"> <img src="https://img.shields.io/badge/Deploy%20To%20Heroku-blueviolet?style=for-the-badge&logo=heroku" width="210" height="34.45"/></a></p>
